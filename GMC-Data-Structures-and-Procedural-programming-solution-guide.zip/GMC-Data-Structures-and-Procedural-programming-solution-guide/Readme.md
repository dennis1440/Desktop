This repo contains two algos:

Sum_of_distinct.algo
Vector.algo

The Sum_of_distinct algo checks for distinct elements between 2 arrays and sums up the distinct elements. It does this by receiving the elements of each array from a user, using a function named 'array_elements'. It then uses a 'check_distinct' function which containes nested loops to compare all elements of one array to the other, and vice versa.

The algo then gets the total sum of distinct elements.

The second algorithm which is the vector.algo determines whether any two pairs of vectors in a given set of vector pairs are orthogonal. the algorithm uses a nested loop to request for inputs for all pairs of vectors in a multidimensional array. It then uses a procedure named "dot_product" to determine orthogonality of any two vectors in the set.
